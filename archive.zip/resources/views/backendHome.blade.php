@extends('layouts.backend')
@section('title','後台首頁')
@section('h1','WELCOME EASTFARM BACKEND CONSOLE')
@section('content')
<div class="d-flex justify-center align-center">
    <img class="img-fluid" src="{{ asset('/assets/source/eastfarmLogo.png') }}" alt="" style="width:500px;">
</div>
@endsection
