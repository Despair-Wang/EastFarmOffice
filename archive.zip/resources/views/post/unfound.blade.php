@extends('layouts.basic')
@section('title','該內容不存在')
@section('h1','該內容不存在')
@section('content')
    <h2 class="h2">很抱歉，您搜尋的內容並不存在，或搜尋依據已經失效了
    </h2>
@endsection
